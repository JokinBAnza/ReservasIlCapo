<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('mesas', function (Blueprint $table) {
            $table->id();
            $table->integer('numero')->unique(); // número de mesa
            $table->integer('capacidad');        // capacidad de personas
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('mesas');
    }
};